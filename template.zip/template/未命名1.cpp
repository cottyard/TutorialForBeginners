#include <SFML/Graphics.hpp>

sf::RenderWindow window;

int main() {
    window.create(sf::VideoMode(1000, 1000), "5");
    while(window.isOpen()) {
        sf::Event event;
        while(window.pollEvent(event)) {
            if(event.type == sf::Event::Closed) window.close();
        }
 
        window.clear();
        
        sf::RectangleShape background(sf::Vector2f(1000, 1000));
	    background.setFillColor(sf::Color(245, 222, 179));
	    window.draw(background);

        window.display();
    }
    return 0;
}

